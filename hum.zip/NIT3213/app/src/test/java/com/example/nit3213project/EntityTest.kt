package com.example.nit3213project

import org.junit.jupiter.api.Assertions.*

class EntityTest